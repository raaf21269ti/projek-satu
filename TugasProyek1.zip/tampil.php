<?php
require_once 'atas.php'
?>

<?php
require_once 'bawah.php'
?>